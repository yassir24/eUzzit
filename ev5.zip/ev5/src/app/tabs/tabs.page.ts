import { Component } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { ModalController } from '@ionic/angular';
import { UpdateAppPage } from '../pages/update-app/update-app.page';
import { FcmService } from '../services/fcm.service';

@Component({
  selector: 'app-tabs',
  templateUrl: 'tabs.page.html',
  styleUrls: ['tabs.page.scss']
})
export class TabsPage {
  latestversion: any
  version = 10207
  systemtoken: any;
  constructor( public fcm: FcmService, private modalController: ModalController, private db: AngularFirestore) {
    this.systemtoken = fcm.token;
    console.log('this is my token', this.systemtoken)

    // this.presentModal()
    this.chechVersion()
  }



  chechVersion() {
    this.db.collection('versions').snapshotChanges().subscribe(res =>{
      this.latestversion = res
      console.log('this is the version', this.latestversion[0].payload.doc.data().number)
      if (this.latestversion[0].payload.doc.data().number > this.version) {
        this.presentModal()
      }
    })
  }

  async presentModal() {
    const modal = await this.modalController.create({
      component: UpdateAppPage,
      cssClass: 'alert-modal',
      componentProps: { 
        version: this.latestversion[0].payload.doc.data().name
      }
    });
    return await modal.present();
  }




}
