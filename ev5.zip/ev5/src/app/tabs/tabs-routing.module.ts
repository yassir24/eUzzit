import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs.page';

const routes: Routes = [
  {
    path: '',
    component: TabsPage,
    children: [
      {
        path: 'home',
        loadChildren: () => import('../pages/home/home.module').then(m => m.HomePageModule)
      },
      {
        path: 'fundwallet',
        loadChildren: () => import('../pages/transact/fundwallet/fundwallet.module').then(m => m.FundwalletPageModule)
      },
      {
        path: 'merchant',
        loadChildren: () => import('../pages/merchant/merchant.module').then(m => m.MerchantPageModule)
      },
      {
        path: 'profile',
        loadChildren: () => import('../pages/profile/profile/profile.module').then(m => m.ProfilePageModule)
      },
      {
        path: 'wallet',
        loadChildren: () => import('../pages/wallet/wallet.module').then(m => m.WalletPageModule)
      },
      {
        path: '',
        redirectTo: '/dashboard/home',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: '/dashboard/home',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
})
export class TabsPageRoutingModule {}
