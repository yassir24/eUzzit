import { Component, OnInit, Input } from "@angular/core";
import { ModalController } from "@ionic/angular";


@Component({
  selector: 'app-transaction-details',
  templateUrl: './transaction-details.page.html',
  styleUrls: ['./transaction-details.page.scss'],
})
export class TransactionDetailsPage implements OnInit {

  @Input() data: any;

  constructor(public modalController: ModalController) {}

  ngOnInit() {
    console.log(this.data);
  }

  dismissModal() {
    // using the injected ModalController this page
    // can "dismiss" itself and optionally pass back data
    this.modalController.dismiss({
      dismissed: true,
    });
  }

  abs(n: number) {
    return Math.abs(n);
  }

}
