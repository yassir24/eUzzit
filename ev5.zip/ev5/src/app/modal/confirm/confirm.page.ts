import { Component, OnInit, Input } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { BillerService } from 'src/app/services/biller.service';
import { first } from 'rxjs/internal/operators/first';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-confirm',
  templateUrl: './confirm.page.html',
  styleUrls: ['./confirm.page.scss'],
})
export class ConfirmPage implements OnInit {

  @Input() data: any;
  @Input() amount: string;
  @Input() charge: string;
  @Input() rawdata: any;
  @Input() etype: any;
  @Input() meterno: any;
  @Input() wallet: any;
  amountsymbol: any;
  chargesymbol: any;
  totalamountsymbol: any;
  total: number;
  coins: any;
  submitSend = false;
  userdata: any;


  customer: {name: string, data: string}[];

  successheader: string;
  successmessages: string;
  comments = [];
  success = false;
  results = [];


  constructor(
    public modalController: ModalController,
    public storage: Storage,
    public billerService: BillerService) {
      this.loadReceipts();
   }

  ngOnInit() {

    console.log(this.data);

    this.amountsymbol = '&#8358;' + this.amount;
    this.chargesymbol = '&#8358;' + this.charge;
    this.total = (parseInt(this.amount) + parseInt(this.charge));
    this.totalamountsymbol = '&#8358;' + this.total;
  }

  dismissModal() {
    // using the injected ModalController this page
    // can "dismiss" itself and optionally pass back data
    this.modalController.dismiss({
      dismissed: true
    });
  }

  async loadReceipts() {

    this.results = await this.storage.get('electricity');
    this.userdata = await this.storage.get('user');
  }

  onClick() {
    this.submitSend = true;
    const data =  {
      contacttype: 'landlord',
      account: this.meterno,
      type: this.etype,
      amount: this.amount,
      wallet: this.wallet
    };
    this.billerService.vendElectricity(data)
    .pipe(first())
    .subscribe(
      data => {
        console.log(data);

        if (data.confirmationCode === 200) {
              this.results.push(data);

              this.success = true;

              this.successheader = 'Transaction Successful!';

              this.coins = data.coins;

              if (data.ProductType === 16) {
                this.successmessages = '<ion-text class="fw-600 fs-19" text-center>' + data.vendData.creditToken + '</ion-text><br />';
                this.successmessages += 'Transaction Amount: ' + data.Amount + '<br />';
                this.successmessages += 'Tariff Reference: ' + data.vendData.tariff + '<br />';
                this.successmessages += 'Transaction Reference' + data.vendData.exchangeReference + '<br />';
               }

              this.submitSend = false;

              this.storage.set('electricity', this.results);


              // this.successmessages += (data.returnMessage != null) ? data.returnMessage : this.subtitle + '<br /> Subscription for '+this.p.smartcard.value+' successful!';
              // this.is_success = true;
          } else {
            this.submitSend = false;


          }
      }
    );
  }

}
