import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ConfirmSendPageRoutingModule } from './confirm-send-routing.module';

import { ConfirmSendPage } from './confirm-send.page';
import { ComponentsModule } from '../../components/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ComponentsModule,
    ConfirmSendPageRoutingModule
  ],
  declarations: [ConfirmSendPage]
})
export class ConfirmSendPageModule {}
