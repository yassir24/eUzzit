import { Component, OnInit, Input } from "@angular/core";
import { ModalController,
  //  Events, 
   AlertController } from "@ionic/angular";
import { first } from "rxjs/internal/operators/first";
import { TransactionService } from "../../services/transaction.service";
import { faWallet } from "@fortawesome/free-solid-svg-icons";
import { PusherServiceProvider } from "../../providers/pusher-service.service";
import { CheckpinService } from "../../services/checkpin.service";
import { EventsService } from "src/app/services/events.service";

@Component({
  selector: 'app-confirm-send',
  templateUrl: './confirm-send.page.html',
  styleUrls: ['./confirm-send.page.scss'],
})
export class ConfirmSendPage implements OnInit {

  @Input() receiver: any;
  @Input() amount: string;
  @Input() wallet: any;
  @Input() transfernumbers: any;

  amountsymbol: any;
  total: any;
  charges: any;
  coins: any;
  faWallet = faWallet;

  successheader: string;
  successmessages: string;
  comments = [];
  success = false;
  submitted = false;

  constructor(
    public modalController: ModalController,
    // public events: Events,
    private events: EventsService,
    public pinService: CheckpinService,
    public alertController: AlertController,
    public transactionService: TransactionService
  ) {}

  ngOnInit() {
    this.amountsymbol = this.transfernumbers.amount;

    this.total = this.transfernumbers.total;

    this.charges = this.transfernumbers.charge;

    this.coins = this.transfernumbers.coin;
  }

  dismissModal() {
    // using the injected ModalController this page
    // can "dismiss" itself and optionally pass back data
    this.modalController.dismiss({
      dismissed: true,
    });
  }

  ionViewDidLoad() {}

  async presentAlert(msg: any) {
    const alert = await this.alertController.create({
      header: msg.head,
      message: msg.body,
      buttons: ["OK"],
    });
    await alert.present();
  }

  async protectSendMoney() {
    this.submitted = true;
    const result = await this.pinService.runCheck();

    if (result === true) {
      this.sendMoney();
    } else {
      this.submitted = false;
    }
  }

  sendMoney() {
    console.log(this.wallet, " ", this.receiver.phone, " ", this.amount);
    this.transactionService
      .transfer(this.receiver.phone, this.amount, this.wallet.slug)
      .pipe(first())
      .subscribe((data) => {
        console.log(data);

        this.events.publish("transfer", { action: "Transfer Success!"});
        this.successmessages = data.message;
        this.successheader = `SUCCESS`;

        this.success = true;
        this.coins = data.coins;
        this.submitted = false;
      });
  }

}
