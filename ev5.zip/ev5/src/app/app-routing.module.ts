import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { CompleteProfileGuard } from './guards/complete-profile.guard';
import { NoAuthGuard } from './guards/no-auth.guard';
import { TutorialGuard } from './guards/tutorial.guard';
import { UserGuard } from './guards/user.guard';

const routes: Routes = [
  { path: '', redirectTo: "login", pathMatch: "full" },
  {
    path: 'dashboard',
    loadChildren: () => import('./tabs/tabs.module').then(m => m.TabsPageModule),
    canActivate: [UserGuard],
    
  },
  {
    path: 'confirm',
    loadChildren: () => import('./modal/confirm/confirm.module').then( m => m.ConfirmPageModule)
  },
  {
    path: 'confirm-send',
    loadChildren: () => import('./modal/confirm-send/confirm-send.module').then( m => m.ConfirmSendPageModule)
  },
  {
    path: 'iframe',
    loadChildren: () => import('./modal/iframe/iframe.module').then( m => m.IframePageModule)
  },
  {
    path: 'transaction-details',
    loadChildren: () => import('./modal/transaction-details/transaction-details.module').then( m => m.TransactionDetailsPageModule)
  },
  {
    path: 'accounts',
    loadChildren: () => import('./pages/accounts/accounts.module').then( m => m.AccountsPageModule)
  },
  {
    path: 'forgot-password',
    loadChildren: () => import('./pages/auth/forgot-password/forgot-password.module').then( m => m.ForgotPasswordPageModule),
    canActivate: [NoAuthGuard],
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/auth/login/login.module').then( m => m.LoginPageModule),
    canActivate: [TutorialGuard]
  },
  {
    path: 'signup',
    loadChildren: () => import('./pages/auth/signup/signup.module').then( m => m.SignupPageModule),
    canActivate: [NoAuthGuard],
  },
  {
    path: 'validate-phone',
    loadChildren: () => import('./pages/auth/validate-phone/validate-phone.module').then( m => m.ValidatePhonePageModule)
  },
  {
    path: 'airtime',
    loadChildren: () => import('./pages/bills/airtime/airtime.module').then( m => m.AirtimePageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'buyairtime',
    loadChildren: () => import('./pages/bills/buyairtime/buyairtime.module').then( m => m.BuyairtimePageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'cable',
    loadChildren: () => import('./pages/bills/cable/cable.module').then( m => m.CablePageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'cable-product',
    loadChildren: () => import('./pages/bills/cable-product/cable-product.module').then( m => m.CableProductPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'electricity',
    loadChildren: () => import('./pages/bills/electricity/electricity.module').then( m => m.ElectricityPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'internet',
    loadChildren: () => import('./pages/bills/internet/internet.module').then( m => m.InternetPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'internet-product',
    loadChildren: () => import('./pages/bills/internet-product/internet-product.module').then( m => m.InternetProductPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'coins',
    loadChildren: () => import('./pages/coins/coins.module').then( m => m.CoinsPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'education',
    loadChildren: () => import('./pages/education/education.module').then( m => m.EducationPageModule)
  },
  {
    path: 'home',
    loadChildren: () => import('./pages/home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'access',
    loadChildren: () => import('./pages/loans/access/access.module').then( m => m.AccessPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'access-two',
    loadChildren: () => import('./pages/loans/access-two/access-two.module').then( m => m.AccessTwoPageModule)
  },
  {
    path: 'details/:id',
    loadChildren: () => import('./pages/loans/details/details.module').then( m => m.DetailsPageModule)
  },
  {
    path: 'history',
    loadChildren: () => import('./pages/loans/history/history.module').then( m => m.HistoryPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'pay',
    loadChildren: () => import('./pages/loans/pay/pay.module').then( m => m.PayPageModule)
  },
  {
    path: 'home',
    loadChildren: () => import('./pages/merchants/home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'merchant-profile',
    loadChildren: () => import('./pages/merchants/merchant-profile/merchant-profile.module').then( m => m.MerchantProfilePageModule)
  },
  {
    path: 'merchant-reward',
    loadChildren: () => import('./pages/merchants/merchant-reward/merchant-reward.module').then( m => m.MerchantRewardPageModule)
  },
  {
    path: 'merchant-settings',
    loadChildren: () => import('./pages/merchants/merchant-settings/merchant-settings.module').then( m => m.MerchantSettingsPageModule)
  },
  {
    path: 'home',
    loadChildren: () => import('./pages/merchant/home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'merchant',
    loadChildren: () => import('./pages/merchants/home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'about',
    loadChildren: () => import('./pages/merchant-management/about/about.module').then( m => m.AboutPageModule)
  },
  {
    path: 'container',
    loadChildren: () => import('./pages/merchant-management/container/container.module').then( m => m.ContainerPageModule)
  },
  {
    path: 'dashboard',
    loadChildren: () => import('./pages/merchant-management/dashboard/dashboard.module').then( m => m.DashboardPageModule)
  },
  {
    path: 'paymenthistory',
    loadChildren: () => import('./pages/merchant-management/paymenthistory/paymenthistory.module').then( m => m.PaymenthistoryPageModule)
  },
  {
    path: 'photo',
    loadChildren: () => import('./pages/merchant-management/photo/photo.module').then( m => m.PhotoPageModule)
  },
  {
    path: 'services',
    loadChildren: () => import('./pages/merchant-management/services/services.module').then( m => m.ServicesPageModule)
  },
  {
    path: 'settings',
    loadChildren: () => import('./pages/merchant-management/settings/settings.module').then( m => m.SettingsPageModule)
  },
  {
    path: 'viewinvoice',
    loadChildren: () => import('./pages/merchant-management/viewinvoice/viewinvoice.module').then( m => m.ViewinvoicePageModule)
  },
  {
    path: 'merchant-services',
    loadChildren: () => import('./pages/merchant-services/merchant-services.module').then( m => m.MerchantServicesPageModule)
  },
  {
    path: 'notify',
    loadChildren: () => import('./pages/notify/notify.module').then( m => m.NotifyPageModule)
  },
  {
    path: 'terms',
    loadChildren: () => import('./pages/other/terms/terms.module').then( m => m.TermsPageModule)
  },
  {
    path: 'payments',
    loadChildren: () => import('./pages/payments/payments.module').then( m => m.PaymentsPageModule)
  },
  {
    path: 'complete-profile',
    loadChildren: () => import('./pages/profile/complete-profile/complete-profile.module').then( m => m.CompleteProfilePageModule),
    canActivate: [CompleteProfileGuard],
  },
  {
    path: 'invite',
    loadChildren: () => import('./pages/profile/invite/invite.module').then( m => m.InvitePageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'lifeline',
    loadChildren: () => import('./pages/profile/lifeline/lifeline.module').then( m => m.LifelinePageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'password-settings',
    loadChildren: () => import('./pages/profile/password-settings/password-settings.module').then( m => m.PasswordSettingsPageModule)
  },
  {
    path: 'pin-settings',
    loadChildren: () => import('./pages/profile/pin-settings/pin-settings.module').then( m => m.PinSettingsPageModule)
  },
  {
    path: 'profile',
    loadChildren: () => import('./pages/profile/profile/profile.module').then( m => m.ProfilePageModule)
  },
  {
    path: 'upgrade',
    loadChildren: () => import('./pages/profile/upgrade/upgrade.module').then( m => m.UpgradePageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'profile-settings',
    loadChildren: () => import('./pages/profile/settings/settings.module').then( m => m.SettingsPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'sendmoney',
    loadChildren: () => import('./pages/sendmoney/sendmoney.module').then( m => m.SendmoneyPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'set-pin',
    loadChildren: () => import('./pages/set-pin/set-pin.module').then( m => m.SetPinPageModule)
  },
  {
    path: 'setup-pin',
    loadChildren: () => import('./pages/setup-pin/setup-pin.module').then( m => m.SetupPinPageModule)
  },
  {
    path: 'showfund',
    loadChildren: () => import('./pages/showfund/showfund.module').then( m => m.ShowfundPageModule)
  },
  {
    path: 'activate-wallet',
    loadChildren: () => import('./pages/transact/activate-wallet/activate-wallet.module').then( m => m.ActivateWalletPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'fundwallet',
    loadChildren: () => import('./pages/transact/fundwallet/fundwallet.module').then( m => m.FundwalletPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'jamb',
    loadChildren: () => import('./pages/transact/jamb/jamb.module').then( m => m.JambPageModule)
  },
  {
    path: 'scan2pay',
    loadChildren: () => import('./pages/transact/scan2pay/scan2pay.module').then( m => m.Scan2payPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'upgrade-account',
    loadChildren: () => import('./pages/transact/upgrade-account/upgrade-account.module').then( m => m.UpgradeAccountPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'waec',
    loadChildren: () => import('./pages/transact/waec/waec.module').then( m => m.WaecPageModule)
  },
  {
    path: 'withdraw',
    loadChildren: () => import('./pages/transact/withdraw/withdraw.module').then( m => m.WithdrawPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'transactions',
    loadChildren: () => import('./pages/transactions/transactions.module').then( m => m.TransactionsPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'bank-transfer',
    loadChildren: () => import('./pages/transfers/bank/bank.module').then( m => m.BankPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'merchant-payment',
    loadChildren: () => import('./pages/transfers/merchant/merchant.module').then( m => m.MerchantPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'merchant-process',
    loadChildren: () => import('./pages/transfers/merchant-process/merchant-process.module').then( m => m.MerchantProcessPageModule)
  },
  {
    path: 'wallet-wallet',
    loadChildren: () => import('./pages/transfers/wallet/wallet.module').then( m => m.WalletPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'upgrade-to-premium',
    loadChildren: () => import('./pages/upgrade-to-premium/upgrade-to-premium.module').then( m => m.UpgradeToPremiumPageModule),
    canActivate: [UserGuard],
  },
  {
    path: 'wallet',
    loadChildren: () => import('./pages/wallet/wallet.module').then( m => m.WalletPageModule)
  },
  {
    path: 'zit',
    loadChildren: () => import('./pages/zit-status/zit-status.module').then( m => m.ZitStatusPageModule)
  },
  {
    path: 'alert-modal',
    loadChildren: () => import('./pages/alert-modal/alert-modal.module').then( m => m.AlertModalPageModule)
  },
  {
    path: 'welcome',
    loadChildren: () => import('./pages/welcome/welcome.module').then( m => m.WelcomePageModule),
  },
  {
    path: 'update-app',
    loadChildren: () => import('./pages/update-app/update-app.module').then( m => m.UpdateAppPageModule)
  }
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
