import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { environment } from '../environments/environment.prod';


import { AngularFireModule } from '@angular/fire';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFirestoreModule } from '@angular/fire/firestore';
import { AngularFireDatabaseModule } from '@angular/fire/database';
import { AngularFireStorageModule } from '@angular/fire/storage';
import { AngularFireFunctionsModule } from '@angular/fire/functions';
import { AngularFireMessagingModule } from '@angular/fire/messaging';
import { SplashScreen } from "@ionic-native/splash-screen/ngx";
import { StatusBar } from "@ionic-native/status-bar/ngx";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { UserGuard } from "./guards/user.guard";
import { JwtInterceptor } from "./interceptors/jwt-interceptor";
import { Config } from "./providers/config";
import { IonicStorageModule } from "@ionic/storage";
import { InAppBrowser } from "@ionic-native/in-app-browser/ngx";
import { Contacts } from "@ionic-native/contacts/ngx";
import { LocalNotifications } from "@ionic-native/local-notifications/ngx";
import { Clipboard } from "@ionic-native/clipboard/ngx";
import { FontAwesomeModule } from "@fortawesome/angular-fontawesome";
import { Camera, CameraOptions } from "@ionic-native/camera/ngx";
import {
  FileTransfer,
  FileUploadOptions,
  FileTransferObject,
} from "@ionic-native/file-transfer/ngx";
import { TouchID } from "@ionic-native/touch-id/ngx";
import { SuperTabsModule } from "@ionic-super-tabs/angular";

import { DatePipe, CurrencyPipe } from "@angular/common";
import { PusherServiceProvider } from "./providers/pusher-service.service";
import { Crop } from "@ionic-native/crop/ngx";
import { Device } from "@ionic-native/device/ngx";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { AndroidPermissions } from "@ionic-native/android-permissions/ngx";

import { NgIdleKeepaliveModule } from "@ng-idle/keepalive";
import { SocketIoModule, SocketIoConfig } from "ngx-socket-io";
const config: SocketIoConfig = {
  url: "http://euzZittaging.com.ng:3001",
  options: {},
};


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ComponentsModule } from './components/components.module';
import { PinComponent } from './components/pin/pin.component';
import { IframePage } from './modal/iframe/iframe.page';
import { TimerComponent } from './components/timer/timer.component';
import { ConfirmSendPage } from './modal/confirm-send/confirm-send.page';
import { ConfirmPage } from './modal/confirm/confirm.page';
import { TransactionDetailsPage } from './modal/transaction-details/transaction-details.page';
import { SetPinComponent } from './components/set-pin/set-pin.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    PinComponent,
    IframePage,
    TimerComponent,
    ConfirmSendPage,
    ConfirmPage,
    TransactionDetailsPage,
    SetPinComponent,
  ],
  entryComponents: [ 
    PinComponent,
    ConfirmSendPage,
    ConfirmPage,
    TransactionDetailsPage,
    SetPinComponent,
  ],
  imports: [
    FormsModule,
    BrowserModule, 
    BrowserAnimationsModule,
    IonicModule.forRoot({
      mode: 'md'
    }),
    AngularFireModule.initializeApp(environment.firebase),
    AngularFireDatabaseModule,
    AngularFireStorageModule,
    AngularFirestoreModule, // imports firebase/firestore
    AngularFireAuthModule,
    AngularFireMessagingModule,
    AngularFireFunctionsModule,
    SocketIoModule.forRoot(config),
    HttpClientModule,
    ComponentsModule,
    FontAwesomeModule,
    SuperTabsModule.forRoot(),
    SuperTabsModule.forRoot(),
    IonicStorageModule.forRoot(),
    NgIdleKeepaliveModule.forRoot(),
    AppRoutingModule,
  ],
  
  providers: [
    Clipboard,
    Camera,
    // tslint:disable-next-line: deprecation
    FileTransfer,
    Crop,
    TouchID,
    Device,
    AndroidPermissions,
    StatusBar,
    SplashScreen,
    UserGuard,
    LocalNotifications,

    // tslint:disable-next-line: deprecation
    Contacts,

    PusherServiceProvider,
    InAppBrowser,
    DatePipe,
    CurrencyPipe,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: JwtInterceptor,
      multi: true,
    },
    Config,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }],
  bootstrap: [AppComponent],
})
export class AppModule {}
