import { Component, OnInit } from '@angular/core';
import { BillerService } from '../../../services/biller.service';
import { NavigationExtras, Router } from '@angular/router';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-cable',
  templateUrl: './cable.page.html',
  styleUrls: ['./cable.page.scss'],
})
export class CablePage implements OnInit {

  cabletvs: any;
  loaded: boolean = false;

  constructor(
    public billerService: BillerService,
    private router: Router,
    private toastController: ToastController
  ) { }


  ngOnInit() {
    this.billerService.getCableTvBillers().subscribe(res => {
      console.log(res.data)
      this.cabletvs = res.data;
      this.loaded = true;
     });

  }

  abs(n: number) {
    return Math.abs(n).toLocaleString('en-US');
  }

  arrayOne(n: number): any[] {
    return Array(n);
  }
  
  openService( service: any) {
    // if(!service.active)
    // {
    //   this.presentToast('Coming Soon!');

    //   return;
    // }
    let navigationExtras: NavigationExtras = {
      state: {
        cable: service
      }
    };
    this.router.navigate(['cable-product'], navigationExtras);
  }

  async presentToast( error: string ) {
    const toast = await this.toastController.create({
      message: error,
      duration: 5000
    });
    toast.present();
  }

}
