import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { BillerService } from "../../../services/biller.service";
import {
  ModalController,
  ToastController,
  AlertController,
} from "@ionic/angular";
import { ConfirmPage } from "../../../modal/confirm/confirm.page";
import { Storage } from "@ionic/storage";
import { CheckpinService } from "../../../services/checkpin.service";
import { WalletService } from "../../../services/wallet.service";
import { faLeaf } from "@fortawesome/free-solid-svg-icons";

@Component({
  selector: 'app-electricity',
  templateUrl: './electricity.page.html',
  styleUrls: ['./electricity.page.scss'],
})
export class ElectricityPage implements OnInit {

  walletActionSheetOptions;
  issuccess;
  constructor(
    public billerService: BillerService,
    public formBuilder: FormBuilder,
    public toastController: ToastController,
    public modalController: ModalController,
    public storage: Storage,
    private pinService: CheckpinService,
    public walletService: WalletService,
    private alertController: AlertController
  ) {
    this.electricityForm = formBuilder.group({
      account: ["", Validators.compose([Validators.required])],
      wallet: ["", Validators.compose([Validators.required])],
      phone_no: ["080000000", Validators.compose([Validators.required])],
      account_name: ["", Validators.compose([Validators.required])],
      amount: [
        "",
        Validators.compose([Validators.required, Validators.min(100)]),
      ],
      service_id: ["", Validators.compose([Validators.required])],
    });
  }

  get p() {
    return this.electricityForm.controls;
  }
  get f() {
    return this.electricityForm.value;
  }

  billers: any;
  billers2: any;
  wallets: any = [];
  loaded = false;
  sbiller: any;
  showbiller = false;
  electricityForm: FormGroup;
  verifydata: any;
  submitSend = false;
  savedData: any = [];
  charges: any;
  savetransaction: any;
  phone: any;
  accountNameValid: boolean;
  success: boolean = false;
  successHeader: any;
  successMessage: any;
  coins: any;

  // compareWith = this.compareWithFn();

  compareWithFn = (o1: any, o2: any) => {
    return o1 && o2 ? o1.id === o2.id : o1 === o2;
  };

  ngOnInit() {

    console.log('this is the sbillier', this.sbiller)
    console.log("ll");
    this.storage.get("user").then((user) => {
      this.phone = user.phone;
    });
    this.walletService.getMyWallets().then((wallet) => {
      this.wallets = wallet;
    });
    this.billerService.getElectricityBillers().subscribe(
      (data) => {
        console.log("This is where the biller is oh", data);
        this.billers = data.data;
        this.billers2 = this.sortBillers();

        for (const iterator of data.wallet) {
          if (iterator.slug !== "shoppy") {
            this.wallets.push(iterator);
          }
        }
      },
      (error) => {
        console.log(error);
      }
    );
    this.loadSavedData();
  }

  abs(n: number) {
    return Math.abs(n).toLocaleString("en-US");
  }

  sortBillers() {
    let billers = [];
    if (typeof this.billers === "object") {
      console.log("this is working", this.billers);
      this.billers.forEach((element) => {
        let location = element.name.split(" ")[0];
        let type = element.name.split(" ")[1];
        location = location.toLowerCase();
        type = type.toLowerCase();

        console.log(location, type);

        let cont = true;

        if (billers.length < 1) {
          let obj = {
            name: null,
            prepaid: null,
            postpaid: null,
            image: element.image,
          };
          obj.name = location;
          obj[type] = element.id;

          billers.push(obj);
        } else {
          for (let elem of billers) {
            if (elem.name == location) {
              elem[type] = element.id;
              cont = false;
            }
          }

          if (cont) {
            let obj = {
              name: null,
              prepaid: null,
              postpaid: null,
              image: element.image,
            };

            obj.name = location;
            obj[type] = element.id;

            billers.push(obj);
          }
        }
      });
    }

    console.log(billers);
    return billers;
  }

  async loadSavedData() {
    this.savedData = await this.storage.get("savedelectricity");
    console.log(this.savedData);
  }

  showBiller(biller: any) {
    // if (!biller.active) {
    //   this.presentToast(biller.name + ' coming soon!');
    //   return;
    // }

    this.sbiller = biller;
    this.showbiller = true;

    console.log('this is the issue',this.sbiller['postpaid']);
  }

  async presentToast(error: string) {
    const toast = await this.toastController.create({
      message: error,
      duration: 5000,
    });
    await toast.present();
  }

  gotoList() {
    this.electricityForm = this.formBuilder.group({
      account: "",
      wallet: "",
      phone_no: "",
      account_name: "",
      amount: "",
      service_id: "",
    });
    this.sbiller = null;
    this.showbiller = false;
  }

  async buyElectricity() {
    if (!this.electricityForm.valid) {
      this.submitSend = false;
      return;
    } else {
      this.submitSend = true;

      this.billerService
        .buyElectricity({ ...this.f })
        .then(
          (res) => {
            console.log(res);
            // this.presentToast(JSON.stringify(res));
            let date = new Date();

            if (res.status === "success") {
              this.successHeader = res.data.transaction_status;
              this.successMessage =
                res.data.transaction_message +
                " successful <br> " +
                " <br><br>Token: " +
                (res.data.credit_token
                  ? res.data.credit_token.creditToken
                  : "");
              this.coins = res.data.coin_earned;
              this.success = true;
              this.submitSend = false;
            } else {
              this.presentToast(res.message);
            }
          },
          (err) => {
            let error = "";
            this.submitSend = false;

            if (err.status >= 400 && err.status < 500) {
              const errorData = err.error.errors;
              if (errorData !== null && typeof errorData !== "object") {
                error += err.error.errors;
              } else {
                for (let key in errorData) {
                  console.log(key);
                  error += errorData[key] + "\n";
                }
              }

              this.presentToast(error);
            }
          }
        )
        .finally(() => (this.submitSend = false));
    }
  }

  // async onVerifyUser() {
  //   if (!this.electricityForm.valid) {
  //     this.submitSend = false;
  //     return;
  //   } else {
  //     this.submitSend = true;
  //     if (await this.pinCheck()) {
  //       this.billerService.verifyElectricity(this.p.plan.value, this.p.meter.value, this.p.amount.value).subscribe(result_data => {
  //         console.log((result_data.confirmationCode === 200 && result_data.details !== undefined));
  //         if (result_data.confirmationCode === 200 && result_data.details !== undefined) {
  //           const data = result_data.details;
  //           const customerdata: any = [];
  //           let message: { name: string, data: string } = null;

  //           for (const key in data) {
  //             if (data.hasOwnProperty(key)) {
  //               const result = key.replace(/([A-Z])/g, ' $1');
  //               message = {
  //                 name: result.charAt(0).toUpperCase() + result.slice(1),
  //                 data: data[key]
  //               };
  //               console.log(key + ' -> ' + data[key]);
  //               if (data[key] != null && typeof data[key] !== 'object') {
  //                 if (key !== 'customernumber' && key !== 'status') {
  //                   customerdata.push(message);
  //                 }

  //                 const index = key.indexOf('ddres');
  //                 if (index !== -1) {

  //                   console.log('indexOf found String :' + index);

  //                   this.electricityForm.patchValue({
  //                     address: data[key]
  //                   });
  //                 }
  //               }
  //             }
  //           }

  //           for (const key in result_data) {
  //             if (result_data.hasOwnProperty(key)) {
  //               const result = key.replace(/([A-Z])/g, ' $1');
  //               message = {
  //                 name: result.charAt(0).toUpperCase() + result.slice(1),
  //                 data: result_data[key]
  //               };
  //               console.log(key + ' -> ' + result_data[key]);
  //               if (result_data[key] != null && typeof result_data[key] !== 'object') {
  //                 if (key !== 'customernumber' && key !== 'status' && key !== 'charge') {
  //                   customerdata.push(message);
  //                 }

  //                 // save the charge seperately
  //                 this.charges = result_data[key];
  //               }
  //             }
  //           }

  //           this.storeSavedData();

  //           this.presentModal(customerdata, this.p.amount.value, data, this.p.plan.value, this.p.meter.value, this.p.wallet.value);
  //         } else {
  //           this.presentToast(result_data.details.message);
  //           this.submitSend = false;
  //           return;
  //         }
  //       });
  //     } else {
  //       this.presentToast('Incorrect pin, please try again later');
  //       this.submitSend = false;
  //     }
  //   }
  // }

  deleteSaved(item: any) {
    const checked = this.savedData.find(
      (x: { meter: any }) => x.meter === item.meter
    );
    if (checked != null) {
      this.savedData.pop(checked);
      this.storage.set("savedelectricity", this.savedData);
    }
  }

  selectItem(item: any) {
    this.electricityForm.patchValue({
      amount: item.amount,
      meter: item.meter,
      wallet: item.wallet,
      address: item.address,
      plan: item.plan,
    });
  }

  storeSavedData() {
    if (this.savetransaction) {
      console.log(this.f);

      if (this.savedData !== null) {
        const checked = this.savedData.find(
          (x: { meter: any }) => x.meter === this.f.meter
        );
        if (checked == null) {
          this.savedData.push(this.f);
          this.storage.set("savedelectricity", this.savedData);
        }
      } else {
        this.savedData = [];
        this.savedData.push(this.f);
        console.log(this.savedData);
        this.storage.set("savedelectricity", this.savedData);
      }
    }

    console.log(this.savedData);
  }

  // async presentModal(verified: any, amount: string, data: any, ctype: any, meterno: any, wallet: any) {
  //   const modal = await this.modalController.create({
  //     component: ConfirmPage,
  //     animated: true,
  //     showBackdrop: true,
  //     backdropDismiss: true,
  //     cssClass: 'confirm-modal',
  //     componentProps: {
  //       data: verified,
  //       amount,
  //       rawdata: data,
  //       etype: ctype,
  //       meterno,
  //       charge: this.charges,
  //       wallet
  //     }
  //   });

  //   this.submitSend = false;
  //   return await modal.present();
  // }

  async presentAlertConfirm() {
    let wallet = this.wallets.find(
      (x: { slug: any }) => x.slug == this.p.wallet
    );

    let messageBody: string = "Service: " + this.sbiller.name + "<br />";
    messageBody += "Meter No: " + this.f.account + "<br />";
    messageBody += "Owner: " + this.f.account_name + "<br />";
    messageBody += "Amount: &#8358;" + this.f.amount + "<br />";
    // messageBody += "Total: &#8358;" + this.p.amount;

    const alert = await this.alertController.create({
      header: "Confirm Transaction!",
      message: messageBody,
      buttons: [
        {
          text: "Cancel",
          role: "cancel",
          cssClass: "secondary",
          handler: (blah) => {
            this.submitSend = false;
          },
        },
        {
          text: "Okay",
          handler: async () => {
            this.buyElectricity();
          },
        },
      ],
    });
    await alert.present();
  }

  dismissModal() {
    this.modalController.dismiss({
      dismissed: true,
    });
  }

  verifyUser() {
    if (this.f.account.length < 1) {
      return;
    }
    console.log("this is calling");
    this.submitSend = true;
    this.billerService
      .verifyElectricity(this.f.service_id, this.f.account)
      .subscribe(
        (payload) => {
          console.log(payload);
          this.electricityForm.patchValue({
            account_name: payload.data.name,
          });
          this.accountNameValid = true;
          // this.accountNumber = this.p.account_no;
          this.submitSend = false;
          // this.retry = false;
        },
        (error) => {
          console.log("this is the ", error);
          this.presentToast(
            "Could not verify meter number. Choose the correct service or check internet connection"
          );
          this.submitSend = false;
          this.accountNameValid = false;
          this.electricityForm.patchValue({
            account_name: "",
          });
        }
      );
  }

  arrayOne(n: number): any[] {
    return Array(n);
  }

  // address: "ABULE - EGBA BU ABULE"
  // ​
  // canVend: "1"
  // ​
  // customerAccountType: "PRIME"
  // ​
  // customerDtNumber: "007903312"
  // ​
  // meterNumber: "23100166208"
  // ​
  // minimumAmount: "0"
  // ​
  // name: "TESTMETER1"

}
