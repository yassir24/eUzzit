import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { InternetProductPage } from './internet-product.page';

const routes: Routes = [
  {
    path: '',
    component: InternetProductPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InternetProductPageRoutingModule {}
