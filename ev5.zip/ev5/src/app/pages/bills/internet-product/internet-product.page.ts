import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { AlertController, ToastController,
  //  Events
   } from "@ionic/angular";
import { BillerService } from "../../../services/biller.service";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Storage } from "@ionic/storage";
import { first } from "rxjs/internal/operators/first";
import { WalletService } from "../../../services/wallet.service";
import { CheckpinService } from "../../../services/checkpin.service";
import {
  Contacts,
  Contact,
  ContactField,
  ContactName,
} from "@ionic-native/contacts/ngx";
import { EventsService } from "src/app/services/events.service";

@Component({
  selector: 'app-internet-product',
  templateUrl: './internet-product.page.html',
  styleUrls: ['./internet-product.page.scss'],
})
export class InternetProductPage implements OnInit {

  shortname: any = null;
  products: any;
  data: any;
  title: string;
  listed: boolean = true;
  item: any = null;
  mainitem: any;
  bundles: any;
  internetForm: FormGroup;
  subtitle: string;
  wallets: any = [];
  error: string;
  walletActionSheetOptions;
  successheader: string;
  successmessages: string;
  is_success: boolean = false;
  coins: any;
  validate: boolean = false;
  submitted: boolean = false;
  showError: boolean;

  error_msg: any;

  itemsloaded: boolean = false;

  smilecustomername: any;
  bundleready: any;
  itemsdata: any;
  amount_available: boolean = false;

  customActionSheetOptions: any = {
    header: "Select a Package",
  };

  // walletActionSheetOptions: any = {
  //   header: 'Choose Wallet',
  //   subHeader: 'Select a Wallet to Use'
  // };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    public formBuilder: FormBuilder,
    public storage: Storage,
    public pinService: CheckpinService,
    public events: EventsService,
    public alertController: AlertController,
    public toastController: ToastController,
    public walletService: WalletService,
    private billerService: BillerService,
    private contacts: Contacts
  ) {
    // this.route.queryParams.subscribe(
    //   params => {
    //   if (this.router.getCurrentNavigation().extras.state) {
    //     this.data = this.router.getCurrentNavigation().extras.state.internet;
    //     console.log(this.data)
    //     this.title = this.data.name + ' Recharge';
    //     this.getPaymentItems();
    //   }
    // });

    this.internetForm = formBuilder.group({
      wallet: ["", Validators.compose([Validators.required])],
      phone_no: ["", Validators.compose([Validators.required])],
      amount: ["", Validators.compose([Validators.required])],
    });

    // this.walletService.getWalletInfo().subscribe(data => {
    //   for (const iterator of data.wallets) {
    //     if (iterator.slug !== 'shoppy') {
    //       this.wallets.push(iterator);
    //     }
    //   }
    // });
  }

  ngOnInit() {
    console.log(this.p);
    this.route.queryParams.subscribe((params) => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.data = this.router.getCurrentNavigation().extras.state.internet;
        console.log("this is the data you are looking for", this.data);
        this.title = this.data.name + " Recharge";
        this.getPaymentItems();
        ``;
      }
    });

    this.walletService.getMyWallets().then((res) => {
      this.wallets = res;
    });
  }

  get p() {
    return this.internetForm.value;
  }

  // getPaymentCode( paymentCode: any ) {
  //   let plan =  this.itemsdata.find((x: { paymentCode: any; }) => x.paymentCode == paymentCode);

  //   this.amount_available = true;
  //   if(plan.amount > 0){
  //     this.internetForm.patchValue({
  //       amount: (plan.amount/100)
  //     });
  //   }else if(plan.itemFee > 0){
  //     this.internetForm.patchValue({
  //       amount: (plan.itemFee/100)
  //     });
  //   }
  // }

  getPaymentItems() {
    this.billerService.getInternetBundles(this.data.id).subscribe((data) => {
      if (data.error != null) {
        this.showError = true;
        this.error_msg = data.error.message;
      }

      this.itemsdata = data.data.products;
      if (this.itemsdata) {
        this.showError = false;
        this.storage.get("user").then((val) => {
          this.internetForm.patchValue({
            phone: val.phone,
          });
        });
      }
      this.itemsloaded = true;
    });
  }

  pickContact() {
    this.contacts.pickContact().then(
      async (con) => {
        let phone = con.phoneNumbers[0].value;
        phone = phone.split(" ").join("");

        if (phone.length > 11) {
          let split = phone.split("+234");
          phone = "0" + split[1];
        }

        this.internetForm.patchValue({
          phone_no: phone,
        });
      },
      (err) => {}
    );
  }

  async onRequestInternet() {
    if (!this.internetForm.valid) {
      this.submitted = false;

      return;
    } else {
      const reqData = {
        amount: this.p.amount.split("-")[0],
        phone_no: this.p.phone_no,
        service_id: this.data.id,
        wallet: this.p.wallet,
        code: this.p.amount.split("-")[1],
      };
      console.log(reqData);

      this.submitted = true;

      this.billerService
        .internetRecharge(reqData)
        .then(
          (data) => {
            if (data.status == "success") {
              this.submitted = false;
              this.successmessages = data.message;
              this.successheader = "SUCCESS";
              this.is_success = true;
              this.coins = data.data.coin_earned;
            } else {
              this.presentToast(data.message);
              this.submitted = false;
            }
          },
          (error) => {
            this.error = "";
            this.submitted = false;

            if (error.status >= 400 && error.status < 500) {
              const errorData = error.error.errors;
              if (errorData !== null && typeof errorData !== "object") {
                this.error += error.error.errors;
              } else {
                for (let key in errorData) {
                  console.log(key);
                  this.error += errorData[key] + "\n";
                }
              }

              this.presentToast(this.error);
            }
          }
        )
        .finally(() => (this.submitted = false));
    }
  }

  abs(n: number) {
    return Math.abs(n).toLocaleString("en-US");
  }

  loadAccountName() {
    if (this.p.account_number.length != 10) return;

    // this.validate = true;
    // this.retry = false;
    // this.accountnamevalid = false;

    // this.transactionService.getAccountName( this.p.bankcode, this.p.account_number ).subscribe(data => {
    //   if(data==null){
    //     this.presentToast('Account Name could not be retrieved. Try again!');
    //     this.submitSend = false;
    //     this.retry = true;
    //   }else if(data.error !== undefined){
    //     this.presentErrorAlert('Error code '+ data.error.code, data.error.message+" ");
    //     this.retry = true;
    //   }else{
    //     console.log(data.accountName);
    //     this.sendMoneyForm.patchValue({
    //       account_name : data.accountName
    //     });
    //     this.accountnamevalid = true;
    //     this.submitSend = false;
    //     this.retry = false;
    //   }
    // }, error => {
    //   console.log(error.error);
    // });
  }

  async presentToast(error: string) {
    const toast = await this.toastController.create({
      message: error,
      duration: 3000,
      animated: true,
      mode: "ios",
      color: "dark",
    });
    toast.present();
  }

  async presentAlert(msg: string) {
    const alert = await this.alertController.create({
      header: "Success!",
      message: msg,
      buttons: ["OK"],
    });
    await alert.present();
  }

  async presentAlertConfirm(messagemsg: string, headermsg: string, data: any) {
    const alert = await this.alertController.create({
      header: headermsg,
      message: messagemsg,
      buttons: [
        {
          text: "Cancel",
          role: "cancel",
          cssClass: "secondary",
          handler: (blah) => {
            console.log("Confirm Cancel: blah");
          },
        },
        {
          text: "Proceed!",
          cssClass: "primary",
          handler: () => {
            // this.billerService.vendCable(
            //   this.data.shortname,
            //   (data.customerName == null)? data.firstName+' '+data.lastName : data.customerName,
            //   (data.customerNumber == null)? data.smartCardNumber : data.customerNumber,
            //   data.invoicePeriod,
            //   this.selected==null? this.p.amount.value : this.selected.price,
            //   this.p.wallet.value)
            // .pipe(first())
            // .subscribe(
            //   data => {
            //       if(data.ResponseMessage == 'SUCCESS')
            //       {
            //           console.log(data);
            //           this.successheader = 'Subscription Successful!'
            //           this.successmessages = 'Transaction Reference' + data.vendData.exchangeReference + '<br />';
            //           this.successmessages += (data.returnMessage != null) ? data.returnMessage : this.subtitle + '<br /> Subscription for '+this.p.smartcard.value+' successful!';
            //           this.coins = data.coins;
            //           this.is_success = true;
            //       }else{
            //       }
            //   }
            // )
          },
        },
      ],
    });
    await alert.present();
  }

  arrayOne(n: number): any[] {
    return Array(n);
  }
}
