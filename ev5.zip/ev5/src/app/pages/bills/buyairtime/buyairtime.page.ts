import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AlertController, LoadingController } from '@ionic/angular';
import { Storage } from '@ionic/storage';
// import { Contacts, Contact, ContactField, ContactName } from '@ionic-native/contacts/ngx';
import { BillerService } from '../../../services/biller.service';

@Component({
  selector: 'app-buyairtime',
  templateUrl: './buyairtime.page.html',
  styleUrls: ['./buyairtime.page.scss'],
})
export class BuyairtimePage implements OnInit {

  buyAirtimeForm: FormGroup;
  showairtimeForm: boolean = false;
	loading: any;
	error: string;
  submitted: boolean = false;
  airtimeData: any;
  billername: string;
  userinfo: any;
  items: any;


  constructor(
    public route: ActivatedRoute, 
    public billerService: BillerService,
    public alertController: AlertController,
		public loadingController: LoadingController,
		public router: Router,
    public formBuilder: FormBuilder,
    public storage: Storage
    // private contacts: Contacts
    ) { 
		this.buyAirtimeForm = formBuilder.group({
			amount: ['', Validators.compose([Validators.required])],
			msisdn: ['', Validators.compose([Validators.minLength(10), Validators.required])]
		});
	}

  ngOnInit() {

    this.userinfo = this.storage.get('user');

    this.route.queryParams.subscribe(params => {
        this.airtimeData = JSON.parse(params["airtime"]);
        this.showairtimeForm = true;
        this.billername = this.airtimeData.name;
         console.log(this.airtimeData);
    });

    if(this.showairtimeForm !== false)
    {
        console.log(this.billername);
    }

  }

  onSendRequest() {
    this.submitted = true;
    if(this.buyAirtimeForm.invalid)
    return;
  }

  abs(n: number) {
    return Math.abs(n).toLocaleString('en-US');
  }

  browseContact() {
  //   this.contacts.pickContact().then((contact) => {
  //     console.log('The following contact has been selected:' + JSON.stringify(contact));
  // },((err) => {
  //     console.log('Error: ' + err);
  // }));
  }

}
