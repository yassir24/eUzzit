import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BuyairtimePage } from './buyairtime.page';

const routes: Routes = [
  {
    path: '',
    component: BuyairtimePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BuyairtimePageRoutingModule {}
