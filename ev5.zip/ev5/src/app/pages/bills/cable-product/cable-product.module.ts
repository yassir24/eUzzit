import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CableProductPageRoutingModule } from './cable-product-routing.module';

import { CableProductPage } from './cable-product.page';
import { ComponentsModule } from 'src/app/components/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    ComponentsModule,
    CableProductPageRoutingModule
  ],
  declarations: [CableProductPage]
})
export class CableProductPageModule {}
