import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CableProductPage } from './cable-product.page';

const routes: Routes = [
  {
    path: '',
    component: CableProductPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CableProductPageRoutingModule {}
