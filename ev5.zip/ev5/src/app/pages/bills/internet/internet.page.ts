import { Component, OnInit } from '@angular/core';
import { BillerService } from '../../../services/biller.service';
import { NavigationExtras, Router } from '@angular/router';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-internet',
  templateUrl: './internet.page.html',
  styleUrls: ['./internet.page.scss'],
})
export class InternetPage implements OnInit {

  internetbillers: any;
  loaded: boolean = false;
  wallets: any = [];

  constructor(
    public billerService: BillerService,
    private router: Router,
    private toastController: ToastController
  ) { }


  ngOnInit() {

    this.billerService.getInternetBillers().subscribe(data => {
      console.log(data);
      this.internetbillers = data.data;
      // for (const iterator of data.wallets) {
      //   if (iterator.slug !== 'shoppy') {
      //     this.wallets.push(iterator);
      //   }
      // }
      this.loaded = true;
     });

  }

  arrayOne(n: number): any[] {
    return Array(n);
  }
  
  openService( service: any) {
    // if(!service.active)
    // {
    //   this.presentToast('Coming Soon!');

    //   return;
    // }
    let navigationExtras: NavigationExtras = {
      state: {
        internet: service
      }
    };
    this.router.navigate(['internet-product'], navigationExtras);
    
  }

  async presentToast( error: string ) {
    const toast = await this.toastController.create({
      message: error,
      duration: 5000
    });
    toast.present();
  }

}
