import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-update-app',
  templateUrl: './update-app.page.html',
  styleUrls: ['./update-app.page.scss'],
})
export class UpdateAppPage implements OnInit {
  version;

  constructor( private modalController: ModalController, private router: Router) { }

  ngOnInit() {
  }

  updateApp() {
    window.location.href = 'https://play.google.com/store/apps/details?id=com.euzzit.wallet';
  }

  close(){
    this.modalController.dismiss()
   }
  


}
