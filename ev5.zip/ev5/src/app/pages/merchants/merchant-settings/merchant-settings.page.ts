import { Component, OnInit } from "@angular/core";
import { ToastController, PopoverController } from "@ionic/angular";
import { InfoComponent } from "../../../components/info/info.component";
import { Storage } from "@ionic/storage";

@Component({
  selector: 'app-merchant-settings',
  templateUrl: './merchant-settings.page.html',
  styleUrls: ['./merchant-settings.page.scss'],
})
export class MerchantSettingsPage implements OnInit {

  userinfo: any;
  loading;
  constructor(
    private popoverCtrl: PopoverController,
    public storage: Storage
  ) {}

  async ngOnInit() {
    await this.storage.get("user").then(
      (val) => {
        console.log(val);
        this.userinfo = val;
        this.loading = false;
      },
      (error) => {
        console.error(error);
      }
    );
  }

  async help() {
    const content = `<ul>
      <li>As a Merchant, you reward your customers (with 1% or more) on every transactions and your dashboard allows you to view all transactions.</li>
      <li>Customer's reward (%) amount is deducted from customer's payments and the balance is credited to your Extra Wallet.</li>
    </ul>`;
    const pop = await this.popoverCtrl.create({
      component: InfoComponent,
      cssClass: "popover",
      componentProps: {
        content,
      },
    });
    await pop.present();
  }

}
