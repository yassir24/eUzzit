import { Component, OnInit, ViewChild } from '@angular/core';
import { ModalController,
  //  Events, 
   IonInfiniteScroll } from '@ionic/angular';
import { TransactionDetailsPage } from '../../modal/transaction-details/transaction-details.page';
import { WalletService } from '../../services/wallet.service';
import { DatePipe } from '@angular/common';
import { TransactionService } from 'src/app/services/transaction.service';
import { EventsService } from 'src/app/services/events.service';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.page.html',
  styleUrls: ['./transactions.page.scss'],
  providers: [DatePipe]

})
export class TransactionsPage implements OnInit {

  transactions: any;
  transaction_title: string = 'Your Transactions';
  today: any = new Date();
  maxDate: any;
  startdate: any;
  enddate: any;
  current_page: any;
  last_page: any;

  @ViewChild(IonInfiniteScroll, {static: false}) infiniteScroll: IonInfiniteScroll;

  constructor(
    public transactionService: TransactionService,
    public modalController: ModalController,
    public datePipe: DatePipe,
    public events: EventsService
  ) { 
    this.events.subscribe('login', (data) =>{
      console.log(data); 
      this.callTransactions();
    });
  }

  ngOnInit() {
   this.callTransactions();
  }

  callTransactions() {
    this.maxDate = this.today.getFullYear()+'-'+(this.today.getMonth()+1)+'-'+this.today.getDate();
    this.transactionService.getTransactions().subscribe(data => {
      this.transactions = data.transactions.data;
      this.current_page = data.transactions.current_page;
      this.last_page = data.transactions.last_page;
     });
  }

  onSearch() {
    if(this.startdate ==  null || this.enddate== null )
    return;

    let start_date = this.datePipe.transform(this.startdate, 'dd-MM-yyyy');
    let end_date = this.datePipe.transform(this.enddate, 'dd-MM-yyyy');

    this.transactionService.getTransactionSearch(start_date, end_date).subscribe(data => {
      console.log(data);
      this.transactions = data.transactions.data;
      this.transaction_title = 'Transactions from '+start_date+' to '+end_date;
     });
  }


  loadMore(event: any) {
      let last_page = ( this.last_page < 20) ? this.last_page : 20; 
      if(this.current_page == last_page)
      {
        event.target.disabled = true;
      }
      else{
       
        this.transactionService.getTransactions( this.current_page + 1 ).subscribe(data => {
         // console.log(data);
          this.transactions = this.transactions.concat(data.transactions.data);
          this.current_page = data.transactions.current_page;
          event.target.complete();
         });
      }

  }


  toggleInfiniteScroll() {
    this.infiniteScroll.disabled = !this.infiniteScroll.disabled;
  }


  async presentTransaction( transaction: any ) {
    const modal = await this.modalController.create({
      component: TransactionDetailsPage,
      animated: true,
      showBackdrop: true,
      backdropDismiss: true,
      cssClass: 'confirm-modal',
      componentProps: {
        'data': transaction
      }
    });
    return await modal.present();
  }
  
  dismissModal() {
    // using the injected ModalController this page
    // can "dismiss" itself and optionally pass back data
    this.modalController.dismiss({
      'dismissed': true
    });
  }

}
