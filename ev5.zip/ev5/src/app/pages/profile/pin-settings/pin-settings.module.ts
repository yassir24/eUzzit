import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PinSettingsPageRoutingModule } from './pin-settings-routing.module';

import { PinSettingsPage } from './pin-settings.page';
import { ComponentsModule } from 'src/app/components/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ComponentsModule,
    IonicModule,
    ReactiveFormsModule,
    PinSettingsPageRoutingModule
  ],
  declarations: [PinSettingsPage]
})
export class PinSettingsPageModule {}
