import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PasswordSettingsPageRoutingModule } from './password-settings-routing.module';

import { PasswordSettingsPage } from './password-settings.page';
import { HoursMinutesSecondsPipe } from '../../../pipes/hours-minutes-seconds.pipe';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    PasswordSettingsPageRoutingModule
  ],
  declarations: [PasswordSettingsPage, HoursMinutesSecondsPipe]
})
export class PasswordSettingsPageModule {}
