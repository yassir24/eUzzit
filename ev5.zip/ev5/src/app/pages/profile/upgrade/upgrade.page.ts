import { Component, OnInit, ViewChild, ViewEncapsulation } from "@angular/core";
import { DatatableComponent } from "@swimlane/ngx-datatable";
import { PopoverController } from "@ionic/angular";
import { InfoComponent } from "../../../components/info/info.component";

@Component({
  selector: 'app-upgrade',
  templateUrl: './upgrade.page.html',
  styleUrls: ['./upgrade.page.scss'],
})
export class UpgradePage implements OnInit {

  successheader;
  successmessages;
  coins;
  success;
  loaded: boolean;
  upgrades: number;
  rows = [
    {
      sn: 1,
      wallet: "3243645768",
      date: Date().toString(),
    },
    {
      sn: 2,
      wallet: "3333333333",
      date: Date().toString(),
    },
    {
      sn: 3,
      wallet: "000000000",
      date: Date().toString(),
    },
    {
      sn: 4,
      wallet: "1111111111",
      date: Date().toString(),
    },
  ];
  limit = 10;
  search: string;
  columns = [
    { prop: "sn", name: "S/No." },
    { prop: "wallet", name: "Wallet ID" },
    { prop: "date", name: "Date and Time" },
  ];
  temp = [];
  @ViewChild(DatatableComponent, { static: false }) table: DatatableComponent;

  constructor(private popoverCtrl: PopoverController) {
    this.upgrades = 0;
    this.loaded = false;
    this.search = "";
  }

  ngOnInit() {
    this.temp = [...this.rows];
  }

  filterDatatable(event) {
    const val = event.target.value.toLowerCase();
    const temp = this.temp.filter((d) => {
      return d.wallet.toLowerCase().indexOf(val) !== -1 || !val;
    });
    this.rows = temp;
    this.table.offset = 0;
  }

  async help() {
    const header = `<h3>Premium Account (Upgrade N18,000)</h3>`;
    const content = `<ion-label color="primary">
                    <p>- Earn 400,000 Zit</p>
                    <p>- Your Zit is trade with other Zit for profit</p>
                    <p>- Enjoy up to 3 years loan repayment plan with less than 1% monthly interest rate.</p>
                    <p>- Get Free Upgrade Code called "LifeLine" to share with friends and family.</p>
                    <ion-label>`;
    const pop = await this.popoverCtrl.create({
      component: InfoComponent,
      cssClass: "popover",
      componentProps: {
        content,
        header,
      },
    });
    await pop.present();
  }

}
