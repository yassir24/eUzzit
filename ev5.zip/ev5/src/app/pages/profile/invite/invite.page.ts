import { Component, OnInit, ViewChild, ViewEncapsulation } from "@angular/core";
import { DatatableComponent } from "@swimlane/ngx-datatable";
import { PopoverController } from "@ionic/angular";
import { InfoComponent } from "../../../components/info/info.component";

@Component({
  selector: 'app-invite',
  templateUrl: './invite.page.html',
  styleUrls: ['./invite.page.scss'],
})
export class InvitePage implements OnInit {

  loaded: boolean;
  coins;
  success;
  successheader;
  successmessages;
  invites: number;
  rows = [
    {
      sn: 1,
      wallet: "3243645768",
      date: Date().toString(),
    },
    {
      sn: 2,
      wallet: "3333333333",
      date: Date().toString(),
    },
    {
      sn: 3,
      wallet: "000000000",
      date: Date().toString(),
    },
    {
      sn: 4,
      wallet: "1111111111",
      date: Date().toString(),
    },
  ];
  limit = 10;
  search: string;
  columns = [
    { prop: "sn", name: "S/No." },
    { prop: "wallet", name: "Wallet ID" },
    { prop: "date", name: "Date and Time" },
  ];
  temp = [];
  @ViewChild(DatatableComponent, { static: false }) table: DatatableComponent;

  constructor(private popoverCtrl: PopoverController) {
    this.invites = 0;
    this.loaded = false;
    this.search = "";
  }

  ngOnInit() {
    this.temp = [...this.rows];
  }

  filterDatatable(event) {
    const val = event.target.value.toLowerCase();
    const temp = this.temp.filter((d) => {
      return d.wallet.toLowerCase().indexOf(val) !== -1 || !val;
    });
    this.rows = temp;
    this.table.offset = 0;
  }
  async help() {
    const header = `<h3>Class Account (Activation N500)</h3>`;
    const content = `<ion-label color="primary">
                    <p>- Earn 5,000 Zit</p>
                    <p>- Enjoy Free Life Insurance Cover and Access Loan with less than 1% monthly interest rate.</p>
                    <ion-label>`;
    const pop = await this.popoverCtrl.create({
      component: InfoComponent,
      cssClass: "popover",
      componentProps: {
        content,
        header,
      },
    });
    await pop.present();
  }

}
