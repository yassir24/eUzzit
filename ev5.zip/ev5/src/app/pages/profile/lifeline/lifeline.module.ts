import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LifelinePageRoutingModule } from './lifeline-routing.module';

import { LifelinePage } from './lifeline.page';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ComponentsModule } from 'src/app/components/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NgxDatatableModule,
    IonicModule,
    ComponentsModule,
    LifelinePageRoutingModule
  ],
  declarations: [LifelinePage]
})
export class LifelinePageModule {}
