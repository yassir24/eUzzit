import { Component, OnInit } from '@angular/core';
import { NavController, ModalController } from '@ionic/angular';

@Component({
  selector: 'app-setup-pin',
  templateUrl: './setup-pin.page.html',
  styleUrls: ['./setup-pin.page.scss'],
})
export class SetupPinPage implements OnInit {

  constructor(
    public navCtrl: NavController, 
    public modelCtrl: ModalController) {

  }

  Pin: String = "";
  ShowPin: Boolean = false;

  eventCapture(event: any) {
    this.ShowPin = false;
    this.Pin = event;
  }

  showPin() {
    this.ShowPin = !this.ShowPin;
  }

  ngOnInit() {
  }

}
