import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SetupPinPageRoutingModule } from './setup-pin-routing.module';

import { SetupPinPage } from './setup-pin.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SetupPinPageRoutingModule
  ],
  declarations: [SetupPinPage]
})
export class SetupPinPageModule {}
