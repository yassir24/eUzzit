import { Component, OnInit } from '@angular/core';
import { WalletService } from '../../services/wallet.service';
import { NavController, ToastController } from '@ionic/angular';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.page.html',
  styleUrls: ['./accounts.page.scss'],
})
export class AccountsPage implements OnInit {

 
  slideProfileOpts = {
    effect: 'flip',
    autoHeight: true,
    speed: 1000,
    spaceBetween: 5,
    loop: true,
    autoplay: false,
    slidesPerView: 3,
};

wallets: any;
transactions: any;
transaction_title : any = 'All Transactions';

constructor(
  public accountService: WalletService, 
  public navCtrl: NavController, 
  public storage: Storage,
  public toastController: ToastController) { }

ngOnInit() {
  this.accountService.getWallets().subscribe(data => {
    console.log(data);
    this.wallets = data.wallet;
    this.transactions = data.transactions;
   });
}

setTransactions(title: any, list: any) {
  this.transaction_title = title;
  this.transactions = list;
}


}
