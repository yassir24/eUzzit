import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Storage } from '@ionic/storage'
import { first } from 'rxjs/internal/operators/first';
import { ToastController, NavController, AlertController, Platform } from '@ionic/angular';
import { BillerService } from '../../services/biller.service';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser/ngx';
import { DomSanitizer } from '@angular/platform-browser';
import { StatusBar } from '@ionic-native/status-bar/ngx';

@Component({
  selector: 'app-showfund',
  templateUrl: './showfund.page.html',
  styleUrls: ['./showfund.page.scss'],
})
export class ShowfundPage implements OnInit {

  fundWalletForm: FormGroup;
  submitted: boolean = false;
  rand: any = "9999" + Math.floor((Math.random() * 100000000000) + 1);
  amount: any;
  externalLink: any;

  options : InAppBrowserOptions = {
    location : 'no',//Or 'no' 
    hidden : 'no', //Or  'yes'
    clearcache : 'yes',
    clearsessioncache : 'yes',
    zoom : 'no',//Android only ,shows browser zoom controls 
    hardwareback : 'yes',
    mediaPlaybackRequiresUserAction : 'no',
    shouldPauseOnSuspend : 'no', //Android only 
    closebuttoncaption : 'Close', //iOS only
    disallowoverscroll : 'no', //iOS only 
    toolbar : 'no', //iOS only 
    enableViewportScale : 'yes', //iOS only 
    allowInlineMediaPlayback : 'no',//iOS only 
    presentationstyle : 'pagesheet',//iOS only 
    fullscreen : 'yes',//Windows only    
};



  constructor(
    public billerService: BillerService, 
		public alertController: AlertController,
    public navCtrl: NavController,
    public formBuilder: FormBuilder, 
    public storage: Storage,
    public toastController: ToastController,
    private iab: InAppBrowser,
    private statusBar: StatusBar,
    public platform: Platform,
    private sanitizer: DomSanitizer
  ) { 

   this.externalLink = this.sanitizer.bypassSecurityTrustResourceUrl("https://pwq.sandbox.interswitchng.com?paymentCode=95101&amount=200000&customerId=08065171327&mobileNumber=08065171327&emailAddress=euzzit@euzzit.com&redirectUrl=http%3A%2F%2Flocalhost%3A8000%2Fapi%2Fpayments&requestReference="+this.rand);
    
    this.fundWalletForm = formBuilder.group({
      amount: ['', Validators.compose([Validators.required])]
    });
  }

  ngOnInit() {
    this.platform.ready().then(() => {

      // let status bar overlay webview
      this.statusBar.overlaysWebView(true);

      // set status bar to white
      this.statusBar.backgroundColorByHexString('#673ab7');
      this.statusBar.styleLightContent();
    });  

  }

  sendPostRequest() {
     // console.log(header);
  }

  get p() { return this.fundWalletForm.controls; }



  openSystem() {
    this.iab.create('https://google.com', '_system', this.options);
  }

  openBlank() {
    this.iab.create("https://pwq.sandbox.interswitchng.com", '_blank', this.options);
//      this.iab.create('https://google.com', '_blank', this.options);
  }

  openSelf() {
    this.iab.create('https://google.com', '_self');
  }


  onConfirmDeposit(): void {
    this.submitted = true;

    if (!this.fundWalletForm.valid) {
        this.submitted = false;
        return;
    } else {

      const browser = this.iab.create("https://pwq.sandbox.interswitchng.com?paymentCode=95101&amount="+(this.p.amount.value*100)+"&customerId=08065171327&mobileNumber=08065171327&emailAddress=euzzit@euzzit.com&redirectUrl=http%3A%2F%2Flocalhost%3A8000%2Fapi%2Fpayments&requestReference="+this.rand, '_blank', this.options);
      browser.hide();

      browser.on('loadstop').subscribe(event => {
        browser.insertCSS({ code: "#page-logo-header, #page-header{ background: #673ab7;} #page-logo-header{background-color:#673ab7; height:20px;} #returnlink{display:none;} #page-logo-header-content, .text{display:none}" });
        browser.executeScript({ code: "webpay.ProcessCardTypeSelection('1|1|1|Card Number|0|Card PIN|2|0|||0|0')"
        });
      });

      browser.on('exit').subscribe(event => {
        //refresh balances
      });

    }

    
    
  }

}
