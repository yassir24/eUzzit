import { Component, OnInit } from '@angular/core';
import { faLandmark, faWallet, faMoneyCheck, faQrcode } from '@fortawesome/free-solid-svg-icons';
import {  } from '@fortawesome/free-solid-svg-icons';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-sendmoney',
  templateUrl: './sendmoney.page.html',
  styleUrls: ['./sendmoney.page.scss'],
})
export class SendmoneyPage implements OnInit {

  faWallet = faWallet;
  faLandmark = faLandmark;
  faMoneyCheck = faMoneyCheck;
  faQrcode = faQrcode;
  constructor(public nav: NavController) { }

  ngOnInit() {
  }


  openPage(page: string) {
      this.nav.navigateForward( page );
  }

}
