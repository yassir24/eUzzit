import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { ToastController } from "@ionic/angular";
import { WalletService } from "../../../services/wallet.service";
import { TransactionService } from "../../../services/transaction.service";
import { CheckpinService } from "../../../services/checkpin.service";
import { CurrencyPipe } from "@angular/common";

@Component({
  selector: 'app-merchant-process',
  templateUrl: './merchant-process.page.html',
  styleUrls: ['./merchant-process.page.scss'],
})
export class MerchantProcessPage implements OnInit {

  submitSend;
  sendMoneyForm: FormGroup;
  successheader: string;
  successmessages: string;
  success: boolean = false;
  submitted: boolean = false;
  coins: any;
  loaded: boolean = true;

  wallets: any;
  customActionSheetOptions: any = {
    header: "Choose Wallet",
    subHeader: "Select wallet to pay from",
  };

  processes: any = {
    merchant: "Swift Software Limited",
    amount: 80000,
    address:
      "23, Rainbow Road, Off Trans-amadi Road, PortHarcourt, Rivers State",
    desc: "Web Design Training",
    reward: 2,
  };

  constructor(
    private formBuilder: FormBuilder,
    public toastController: ToastController,
    public wallet: WalletService,
    public pinService: CheckpinService,
    private cp: CurrencyPipe,
    public transactionService: TransactionService
  ) {
    this.sendMoneyForm = formBuilder.group({
      merchant: [this.processes.merchant],
      amount: [this.amount()],
      address: [this.processes.address],
      desc: [this.processes.desc],
      coin: [this.calculateCoin()],
      reward: [this.processes.reward],
    });
  }

  async pinCheck() {
    const result = await this.pinService.runCheck();
    return result == true;
  }

  ngOnInit() {}

  amount() {
    const a = this.cp.transform(this.processes.amount, "", "", "1.2-2");
    return a;
  }

  calculateCoin() {
    const coin = this.processes.amount + this.processes.reward * 100;
    return this.cp.transform(coin, "", "", "1.2-2");
  }

  abs(n: number) {
    return Math.abs(n).toLocaleString("en-US");
  }

  async validateSend() {
    if (!this.sendMoneyForm.valid) {
      this.submitted = false;
      return;
    } else {
      this.submitted = true;
      if (await this.pinCheck()) {
        this.successmessages = `Payment of &#8358;${this.cp.transform(
          this.processes.amount,
          "",
          "",
          "1.2-2"
        )} sent to ${this.processes.merchant} was successful`;
        this.successheader = "Payment Successful!";
        this.success = true;
      } else {
        await this.presentToast("Incorrect pin");
        this.submitted = false;
        return;
      }
    }
  }

  async presentToast(error: string) {
    const toast = await this.toastController.create({
      message: error,
      duration: 5000,
      mode: "ios",
      color: "dark",
      animated: true,
    });
    await toast.present();
  }

}
