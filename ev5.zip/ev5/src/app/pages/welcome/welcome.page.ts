import { Component, OnInit, ViewChild } from '@angular/core';
import { IonSlides } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { Router } from '@angular/router';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.page.html',
  styleUrls: ['./welcome.page.scss'],
})
export class WelcomePage implements OnInit {

  currentslideIndex = 0;

  constructor(private storage: Storage, private router: Router) {}

  @ViewChild('slides', {static: true}) slides: IonSlides;

  async finish() {
    await this.storage.set('tutorialComplete', true);
    this.router.navigateByUrl('/login');
  }

  ngOnInit(): void {
    //  this.clearStorage(). 
  }

 

  do_getActiveSlide(e: any) {
    this.slides.getActiveIndex().then((index: number) => {
      this.currentslideIndex = index
      console.log("Current active slide index", this.currentslideIndex);
    });
  }

  next() {
    this.slides.slideNext();
  }

}
