import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { CheckpinService } from "../../../services/checkpin.service";
import { TransactionService } from "../../../services/transaction.service";
import { ToastController, PopoverController } from "@ionic/angular";
import { CurrencyPipe } from "@angular/common";
import { InfoComponent } from "../../../components/info/info.component";

@Component({
  selector: 'app-pay',
  templateUrl: './pay.page.html',
  styleUrls: ['./pay.page.scss'],
})
export class PayPage implements OnInit {

  loanBalance: number;
  success: boolean;
  successmessages: any;
  coins;
  compareWith;
  walletActionSheetOptions;
  successheader: any;
  processing: boolean;
  wallets: any = [];

  customActionSheetOptions: any = {
    header: "Choose Wallet",
    subHeader: "Select wallet to pay from",
  };

  frmLoanPayment: FormGroup;

  constructor(
    private checkPinService: CheckpinService,
    private formBuilder: FormBuilder,
    public transactionService: TransactionService,
    private toastCtrl: ToastController,
    private popCtrl: PopoverController,
    private cp: CurrencyPipe
  ) {
    this.loanBalance = 60000;
    this.success = false;
    this.processing = false;
    this.frmLoanPayment = formBuilder.group({
      amount: ["", Validators.compose([Validators.required])],
      wallet: ["", Validators.compose([Validators.required])],
    });
  }

  ngOnInit() {
    this.transactionService.getHistory().subscribe((data) => {
      for (const iterator of data.wallets) {
        if (iterator.slug !== "shoppy") {
          this.wallets.push(iterator);
        }
      }
    });
  }

  async help() {
    const header = "<h3>Your Loan Payment</h3>";
    const content = `<ul>
      <li>You can either make part or complete payment of your "Loan Balance".</li>
      <li>Enter amount below to reduce your "Loan Balance".</li>
    </ul>`;
    const pop = await this.popCtrl.create({
      component: InfoComponent,
      cssClass: "popover",
      componentProps: {
        content,
        header,
      },
    });
    await pop.present();
  }

  async pay() {
    this.processing = true;
    const amount = this.frmLoanPayment.get("amount").value;
    if (amount > 50) {
      if (amount > this.loanBalance) {
        this.processing = false;
        await this.notify(
          `Amount is greater than &#8358; ${this.cp.transform(
            this.loanBalance,
            "",
            "",
            "1.2-2"
          )}`
        );
      } else {
        // Process payment
        const amountLeft = this.loanBalance - amount;
        if (amountLeft < 0) {
          this.successmessages = `Your Loan as been selttled`;
        } else {
          // tslint:disable-next-line:max-line-length
          this.successmessages = `Loan payment of &#8358; ${this.cp.transform(
            amount,
            "",
            "",
            "1.2-2"
          )} is creditted in the "Loan Reserve", Your Loan Balance is &#8358; ${this.cp.transform(
            amountLeft,
            "",
            "",
            "1.2-2"
          )}`;
        }
        this.successheader = "Payment Successful!";
        this.success = true;

        this.processing = false;
      }
    } else {
      this.processing = false;
      await this.notify(
        `Amount must be greater than &#8358; ${this.cp.transform(
          50,
          "",
          "",
          "1.2-2"
        )}`
      );
    }
  }

  async notify(msg) {
    const toast = await this.toastCtrl.create({
      message: msg,
      mode: "ios",
      color: "dark",
      duration: 3000,
      animated: true,
    });
    await toast.present();
  }

}
