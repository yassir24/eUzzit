import { Component, OnInit } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastController, PopoverController } from '@ionic/angular';
import { InfoComponent } from '../../../components/info/info.component';

@Component({
  selector: 'app-access',
  templateUrl: './access.page.html',
  styleUrls: ['./access.page.scss'],
})
export class AccessPage implements OnInit {

  loanStatus: number;
  frmAccessLoan: FormGroup;
  processing: boolean;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private toastCtrl: ToastController,
    private popCtrl: PopoverController
  ) {
    this.processing = false;
    this.loanStatus = 80000;
    this.frmAccessLoan = formBuilder.group({
      amount: ['', Validators.compose([Validators.required])],
      duration: ['', Validators.compose([Validators.required])]
    });
  }

  ngOnInit() {
  }

  async process() {
    this.processing = true;
    const req = {
      loanStatus: this.loanStatus,
      loanAmount: this.frmAccessLoan.get('amount').value,
      loanDuration: this.frmAccessLoan.get('duration').value
    };
    if (req.loanAmount > this.loanStatus) {
      await this.errorM(`Amount can't be greater than Eligible amount`);
      this.processing = false;
    } else if (req.loanAmount < 10) {
      await this.errorM(`Amount should be greater than &#8358; 10`);
      this.processing = false;
    } else {
      const navigationExtras: NavigationExtras = {
        queryParams: {
          loan: JSON.stringify(req)
        }
      };
      this.processing = false;
      this.router.navigate(['access-two'], navigationExtras);
    }
  }

  async help() {
    const header = '<h3>Loan Instructions</h3>';
    const content = `<ul>
      <li>Your "Main Wallet" will be credited with the Loan "Disbursed Amount".</li>
      <li>From your requested loan amount 10% will be kept in your "Loan Reserve".</li>
      <li>Your "Daily Repayment" will be deducted from your "Loan Reserve".</li>
      <li>Your "Loan Reserve" daily repayment deduction countdown is "Days".</li>
      <li>Ensure there is money on your wallet at the end of the countdown</li>
    </ul>`;
    const pop = await this.popCtrl.create({
      component: InfoComponent,
      cssClass: 'popover',
      componentProps: {
        content,
        header
      }
    });
    await pop.present();
  }

  async errorM(message) {
    const toast = await this.toastCtrl.create({
      message,
      mode: 'ios',
      animated: true,
      duration: 3000,
      color: 'dark'
    });
    await toast.present();
  }

}
