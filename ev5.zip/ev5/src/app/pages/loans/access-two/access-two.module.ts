import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AccessTwoPageRoutingModule } from './access-two-routing.module';

import { AccessTwoPage } from './access-two.page';
import { ComponentsModule } from 'src/app/components/components.module';

@NgModule({
  imports: [
    CommonModule,
    ComponentsModule,
    FormsModule,
    IonicModule,
    AccessTwoPageRoutingModule
  ],
  declarations: [AccessTwoPage]
})
export class AccessTwoPageModule {}
