import { Component, OnInit } from "@angular/core";
import { CheckpinService } from "../../../services/checkpin.service";
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: 'app-access-two',
  templateUrl: './access-two.page.html',
  styleUrls: ['./access-two.page.scss'],
})
export class AccessTwoPage implements OnInit {

  success: boolean;
  coins;
  process;
  successmessages: any;
  successheader: any;
  loan: any;
  duration: number;
  loanAmount: number;
  loanStatus: number;
  loanReserve: number;
  dailyPayment: number;
  interestAmount: number;
  disbursedAmount: number;
  interestRate: number;
  totalRepayment: number;
  loanBalance: number;

  constructor(
    private checkPinService: CheckpinService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.success = false;
    this.route.queryParams.subscribe((params) => {
      if (params) {
        this.loan = JSON.parse(params.loan);
      }
    });
  }

  ngOnInit() {
    this.loanAmount = this.loan.loanAmount;
    this.loanStatus = this.loan.loanStatus;
    this.duration = this.sortDuration(this.loan.loanDuration);
    this.loanReserve = this.calLoanReserve(this.loanAmount);
    this.interestRate = this.calIR(this.loan.loanDuration);
    this.interestAmount = this.calInterestAmount(
      this.loan.loanDuration,
      this.loanAmount
    );
    this.totalRepayment = this.calTotalRepayment(
      this.interestAmount,
      this.loanAmount
    );
    this.dailyPayment = this.calDailyRepayment(
      this.totalRepayment,
      this.loan.loanDuration
    );
    this.loanBalance = this.calLoanBalance(
      this.totalRepayment,
      this.loanReserve
    );
    this.disbursedAmount = this.calDisbursedAmount(this.loanAmount);
  }

  calIR(duration) {
    if (duration === "1") {
      return 0.12;
    } else if (duration === "2") {
      return 0.2;
    } else if (duration === "3") {
      return 0.3;
    }
  }

  calDisbursedAmount(amount) {
    const cal = 0.9 * amount;
    return cal;
  }

  calLoanReserve(amount) {
    const cal = 0.1 * amount;
    return cal;
  }

  calDailyRepayment(amount, duration) {
    const cal = amount / this.sortDuration(duration);
    return cal;
  }

  calInterestAmount(duration, loanAmount) {
    const cal = this.calIR(duration) * loanAmount;
    return cal;
  }

  calTotalRepayment(IA, loanAmount) {
    const cal = IA + loanAmount;
    return cal;
  }

  calLoanBalance(TR, LR) {
    const cal = TR - LR;
    return cal;
  }

  sortDuration(duration) {
    if (duration === "1") {
      return 400;
    } else if (duration === "2") {
      return 700;
    } else if (duration === "3") {
      return 1000;
    }
  }

  // async process() {
  //   if (await this.pinCheck()) {
  //     // perform operation
  //     this.successmessages = `&#8358;50,000 Loan Approved \n Your Shoppy Wallet is credited \n with &#8358;45,000`;
  //     this.successheader = 'Congratulations';
  //     this.success = true;
  //   }
  // }

}
