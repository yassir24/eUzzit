import { Component, OnInit, OnChanges } from '@angular/core';
import { LoanService } from '../../services/loan.service';
import { ModalController,
  //  Events 
  } from '@ionic/angular';
import { WalletService } from "../../services/wallet.service";
import {NavigationExtras, Router} from "@angular/router";
import { EventsService } from 'src/app/services/events.service';

@Component({
  selector: 'app-coins',
  templateUrl: './coins.page.html',
  styleUrls: ['./coins.page.scss'],
})
export class CoinsPage implements OnInit {

  euzzitextras: any;
  coin: any;

  constructor(
    protected loanService: LoanService,
    public modalController: ModalController,
    public events: EventsService,
    private walletService: WalletService,
    private router: Router
  ) {    
  this.events.subscribe('login', (data) =>{
    console.log(data); 
    this.callLoanInfo();
  });
}

async ngOnInit() {
  let coin = await this.walletService.getMyCoin();
  console.log(this.coin);
  let x=[];x.push(coin);
  this.coin=Number(x[0].balance);
 this.callLoanInfo();
}

  
callLoanInfo() {
  this.loanService.getLoanInformation().subscribe(res => {
    console.log(res);
    let iconArray = ["las la-wallet", "las la-clipboard-list", "las la-ambulance"]
    res.data.forEach((element, i) => {
      element.icon = iconArray[i];
    });
    this.euzzitextras = res.data;
    console.log(res.data)
    });
}

open(page){
  let navExt: NavigationExtras = {
    queryParams: {
      page: page
    }
  }

  this.router.navigate(["zit"], navExt);
}

arrayOne(n: number): any[] {
  return Array(n);
}

}
