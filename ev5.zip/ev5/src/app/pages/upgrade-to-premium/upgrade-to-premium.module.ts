import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { UpgradeToPremiumPageRoutingModule } from './upgrade-to-premium-routing.module';

import { UpgradeToPremiumPage } from './upgrade-to-premium.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    UpgradeToPremiumPageRoutingModule
  ],
  declarations: [UpgradeToPremiumPage]
})
export class UpgradeToPremiumPageModule {}
