import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upgrade-to-premium',
  templateUrl: './upgrade-to-premium.page.html',
  styleUrls: ['./upgrade-to-premium.page.scss'],
})
export class UpgradeToPremiumPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
