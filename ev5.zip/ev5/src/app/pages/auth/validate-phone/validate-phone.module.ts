import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ValidatePhonePageRoutingModule } from './validate-phone-routing.module';

import { ValidatePhonePage } from './validate-phone.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    ValidatePhonePageRoutingModule
  ],
  declarations: [ValidatePhonePage]
})
export class ValidatePhonePageModule {}
