import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ValidatePhonePage } from './validate-phone.page';

const routes: Routes = [
  {
    path: '',
    component: ValidatePhonePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ValidatePhonePageRoutingModule {}
