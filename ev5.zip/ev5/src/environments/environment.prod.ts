export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAolOFzTmhRrecTO5ZifnwlMpzWdvIvEYg",
    authDomain: "euzzit-inapp.firebaseapp.com",
    projectId: "euzzit-inapp",
    storageBucket: "euzzit-inapp.appspot.com",
    messagingSenderId: "195312578519",
    appId: "1:195312578519:web:b7fc863c10dfeecddb6592",
    measurementId: "G-95SFME1FLZ"
  },
};
